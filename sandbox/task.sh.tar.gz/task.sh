#!/usr/bin/env sh
echo "start http server"
python -m SimpleHTTPServer 9155
